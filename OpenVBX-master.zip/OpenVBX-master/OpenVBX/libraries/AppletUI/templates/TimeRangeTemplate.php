<div class="timepicker-widget">
  <input type="text"
    size="7"
    name="<?php echo "{$name}_from"; ?>"
    value="<?php echo $from; ?>"/>
  to
  <input type="text"
    size="7"
    name="<?php echo "{$name}_to"; ?>"
    value="<?php echo $to; ?>"/>
</div>
