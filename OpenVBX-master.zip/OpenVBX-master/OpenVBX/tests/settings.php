<?php

/*
 *  Path to the CIUnit exclusive index.php file. This is usually under your
 *  libraries directory. 
*/
$path_to_codeigniter = dirname(__FILE__) . '/../libraries/fooStack/fooBase/';