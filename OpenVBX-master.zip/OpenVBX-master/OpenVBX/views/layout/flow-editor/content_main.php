				<div id="yui-main">
						<div class="<?php echo $layout_override ?> yui-b">
								<div id="vbx-main">
								<?php echo $content ?>
								</div><!-- #vbx-main -->
						</div><!-- .yui-b -->
				</div><!-- #yui-main -->


