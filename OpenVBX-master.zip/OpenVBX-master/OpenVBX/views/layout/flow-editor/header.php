
		<div id="hd">
			<h1 id="openvbx-logo"><a href="<?php echo real_site_url((($this->tenant->id > 1)? '/'.$this->tenant->name.'/' : '')).'/'; ?>" class="navigate-away"><span class="replace">OpenVBX</span></a></h1>
			<span id="openvbx-assets" class="hide"><a href="<?php echo asset_url(''); ?>" class="navigate-away"><span class="replace">OpenVBX</span></a></span>
		</div><!-- #hd -->

