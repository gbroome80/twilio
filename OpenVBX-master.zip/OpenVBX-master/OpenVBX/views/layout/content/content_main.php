				<div id="yui-main">
						<div class="<?php echo $layout_override ?> yui-b">
								<div id="vbx-main">
									<div class="vbx-content-banner info-banner hide">
										<a href="" class="close action"><span class="replace">Close</span></a>
										<div class="info-message">
											<h3>Duis quis justo libero</h3>
											<p>Nam egestas libero vitae metus iaculis at scelerisque nisi sollicitudin.</p>
										</div>
									</div><!-- .vbx-banner -->

								<?php echo $content ?>
								</div><!-- #vbx-main -->
						</div><!-- .yui-b -->
				</div><!-- #yui-main -->


