<?php $this->load->view('banners/bug-banners'); ?>
<div id="doc3" class="<?php echo $layout ?>">

<div id="wrapper" class="<?php echo $theme;?>-theme">
