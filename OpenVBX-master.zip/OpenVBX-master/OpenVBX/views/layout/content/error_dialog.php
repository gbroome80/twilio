<div title="Error Occurred" class="dialog error-dialog hide">
	 <div class="error-window">
		 <p class="error-code">0</p>
		 <p class="error-message">An error occurred</p>
	 </div>
</div>
