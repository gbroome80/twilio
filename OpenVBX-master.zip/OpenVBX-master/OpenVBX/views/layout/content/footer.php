		<div id="ft">
			<p class="copyright">OpenVBX &bull; <em>v</em><?php echo OpenVBX::version() ?> r<?php echo OpenVBX::schemaVersion() ?> &mdash; Powered by <a href="http://twilio.com/">Twilio Inc.</a> &bull; <a href="http://www.twilio.com/legal/tos">Terms</a> &bull; <a href="http://www.twilio.com/legal/privacy">Privacy</a></p>
		</div><!-- #ft -->

