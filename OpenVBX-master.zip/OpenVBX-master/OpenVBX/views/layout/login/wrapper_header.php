<script type="text/javascript">
if (window != window.top) { window.top.location = window.location; }
</script>
<div class="<?php echo $layout ?>">

<div id="wrapper" class="<?php echo $theme;?>-theme">


