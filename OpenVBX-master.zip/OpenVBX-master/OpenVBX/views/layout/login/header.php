<?php require_once(VBX_ROOT . '/OpenVBX/views/layout/content/header.php'); ?>
