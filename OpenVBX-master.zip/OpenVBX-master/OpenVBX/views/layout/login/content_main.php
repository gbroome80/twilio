
				<div id="vbx-main">
				<?php echo $content ?>
				</div><!-- #vbx-main -->



