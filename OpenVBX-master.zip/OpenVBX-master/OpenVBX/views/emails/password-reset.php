You have requested to reset your password.
	Click on the following link to complete the process:
<?php echo $reset_url ?>