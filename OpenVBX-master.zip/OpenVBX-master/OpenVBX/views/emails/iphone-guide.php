Follow the two steps below on your iOS device to get setup.  Remember to come back to this email when you're finished with each step.

1. Install the iPhone App:
<?php echo site_url('iphone/install?email='.urlencode($email)); ?>

2. Use the following URL for the quick setup.
<?php echo site_url('iphone/install?email='.urlencode($email)); ?>

Thats it!