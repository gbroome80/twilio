<p>Your server doesn't meet the minimum PHP requirements necessary to run this version of OpenVBX.</p>
<p>PHP version required: <?php echo $php_version_min; ?><br />
PHP version installed: <?php echo $php_version; ?></p>
<p>Installation will not be allowed to continue</p>