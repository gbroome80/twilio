<div id="dlg_change" title="Change the call flow?" class="dialog">
	<p>Changing the call flow will change how this number behaves.</p>
	<p>Are you sure you wish to change this number's call flow?</p>
</div>