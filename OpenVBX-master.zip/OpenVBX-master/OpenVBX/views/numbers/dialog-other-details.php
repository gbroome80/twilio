<div id="dlg_details" title="Number Details" class="dialog">
	<p>This number has the following URL(s) defined:</p>
	<ul class="details"></ul>
	<p>Assigning a flow here will override these urls.</p>
</div>