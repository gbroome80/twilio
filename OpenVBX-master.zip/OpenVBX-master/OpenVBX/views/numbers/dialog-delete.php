<div id="dlg_delete" title="Delete phone number?" class="dialog">
	<p class="hide error-message"></p>
	<p>You can not undo this operation and will not be able to retrieve this number again.</p>
	<p>Are you sure you really want to delete this number?</p>
</div>