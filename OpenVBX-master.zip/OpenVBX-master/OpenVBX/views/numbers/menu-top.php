<div class="vbx-content-menu vbx-content-menu-top">
	<h2 class="vbx-content-heading">Phone Numbers</h2>
	<?php if($count_real_numbers > 0): ?>
	<ul class="phone-numbers-menu vbx-menu-items-right">
		<li class="menu-item"><button class="add-button add number"><span>Get a Number</span></button></li>
	</ul>
	<?php endif; ?>
	<?php echo $pagination; ?>
</div><!-- .vbx-content-menu -->