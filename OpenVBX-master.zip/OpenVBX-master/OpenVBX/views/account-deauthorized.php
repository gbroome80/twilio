<div class="vbx-content-main">

	<div class="vbx-content-menu vbx-content-menu-top">
		<h2 class="vbx-content-heading">Account Deauthorized</h2>
	</div><!-- .vbx-content-menu -->

	<div id="login">		
		<p>This account has been deauthorized. Please contact your administrator.</p>
	</div>

</div>